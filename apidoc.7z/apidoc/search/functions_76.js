var searchData=
[
  ['valid_5femail',['valid_email',['../classSD__Form.html#ad39a262c388bb1ff4852797e0ba2f1d1',1,'SD_Form']]],
  ['validate_5fpost',['validate_post',['../classSD__Form.html#a4ca984e959ebab2f6a8cc2f2d7d50ab4',1,'SD_Form']]]
];
