var searchData=
[
  ['begin_5fregistration',['begin_registration',['../classSD__Meeting__Tool__Election.html#a9f879235750345d12b19251755533041',1,'SD_Meeting_Tool_Election']]],
  ['blocks',['blocks',['../classSD__Meeting__Tool__Printing__Template.html#aa41de576f34fe6d3ec73b47a9e368df1',1,'SD_Meeting_Tool_Printing_Template']]]
];
